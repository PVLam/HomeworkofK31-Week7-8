#include<iostream>
#include<vector>
using namespace std;
class BanhCuon{
    protected:
        double gianhan;
        double giavo;
        double trongluongbanh;
        double trongluongnhan;
        double thanhtien;
        
    public:
        BanhCuon(double gv=0,double gn=0,double tlb=0,double tln=0,double tt=0){
            setGiaNhan(gn);
            setGiaVo(gv);
            setTrongLuongBanh(tlb);
            setTrongLuongNhan(tln);
            setThanhTien(tt);
        }
        void setGiaNhan(double gn){
            gianhan=gn;
        }
        double getGiaNhan(){
            return gianhan;
        }
        void setGiaVo(double gv){
            giavo=gv;
        }
        double getGiaVo(){
            return giavo;
        }
        void setTrongLuongBanh(double tlb){
            trongluongbanh=tlb;
        }
        double getTrongLuongBanh(){
            return trongluongbanh;
        }
        void setTrongLuongNhan(double tln){
            trongluongnhan=tln;
        }
        double getTrongLuongNhan(){
            return trongluongnhan;
        }
        void setThanhTien(double tt){
            thanhtien=tt;
        }
        double getThanhTien(){
            return thanhtien;
        }
        void print(){
            cout<<"Gia vo: "<<giavo<<"d"<<endl;
            cout<<"Gia nhan: "<<gianhan<<"d"<<endl;
            cout<<"Trong luong banh: "<<trongluongbanh<<"g"<<endl;
			cout<<"Trong luong nhan: "<<trongluongnhan<<"g"<<endl;
			cout<<"Thanh tien: "<<getGiaVo()*getTrongLuongBanh()+getGiaNhan()*getTrongLuongNhan()<<thanhtien<<"d"<<endl;
        }
        ~BanhCuon(){
            //cout<<"Huy tu"<<endl;
        }
};


class Chay:public BanhCuon{
    public:
        Chay(double gv=10000,double gn=15000, double tlb=100, double tln=100,double tt=0):BanhCuon(gv,gn,tlb,tln,tt){
        }
        void print(){
        	cout<<"Banh cuon chay."<<endl;
            BanhCuon::print();
            cout<<endl<<endl;
        }
        ~Chay(){
            //cout<<"Huy tu"<<endl;
        }
};


class Mong:public BanhCuon{
    public:
        Mong(double gv=10000,double gn=10000, double tlb=100, double tln=100,double tt=0):BanhCuon(gv,gn,tlb,tln,tt){
        }
        void print(){
        	cout<<"Banh cuon mong."<<endl;
            BanhCuon::print();
            cout<<endl<<endl;
        }
        ~Mong(){
            //cout<<"Huy tu"<<endl;
        }
};


class ThitLon:public BanhCuon{
    public:
        ThitLon(double gv=10000,double gn=20000, double tlb=100, double tln=100,double tt=0):BanhCuon(gv,gn,tlb,tln,tt){
        }
        void print(){
        	cout<<"Banh cuon thit lon."<<endl;
            BanhCuon::print();
            cout<<endl<<endl;
        }
        ~ThitLon(){
            //cout<<"Huy tu"<<endl;
        }
};


class DacBiet:public BanhCuon{
    public:
        DacBiet(double gv=10000,double gn=30000, double tlb=100, double tln=100,double tt=0):BanhCuon(gv,gn,tlb,tln,tt){
        }
        void print(){
        	cout<<"Banh cuon dac biet."<<endl;
            BanhCuon::print();
            cout<<endl<<endl;
        }
        ~DacBiet(){
            //cout<<"Huy tu"<<endl;
        }
};


class DonHang{
	protected:
		vector<BanhCuon*> a;		
	public:
		DonHang(){
		}
		~DonHang(){
			//cout<<"Huy tu"<<endl;
		}
		DonHang(Chay a,Mong b,ThitLon c,DacBiet d){
			this->a=a;
			this->b=b;
			this->c=c;
			this->d=d;
		}
		
		void print(){
			cout<<"ID\t"<<"Ten loai banh\t"<<"Trong luong vo\t"<<"Trong luong nhan\t"<<"Thanh tien\t"<<endl;
			cout<<"1\t"<<"Banh cuon chay\t"<<this->a.getTrongLuongBanh()<<"\t"<<this->a.getTrongLuongNhan()<<"\t"<<this->a.getThanhTien()<<endl;
			cout<<"2\t"<<"Banh cuon mong\t"<<this->b.getTrongLuongBanh()<<"\t"<<this->b.getTrongLuongNhan()<<"\t"<<this->b.getThanhTien()<<endl;
			cout<<"3\t"<<"Banh cuon thit lon\t"<<this->c.getTrongLuongBanh()<<"\t"<<this->c.getTrongLuongNhan()<<"\t"<<this->c.getThanhTien()<<endl;
			cout<<"4\t"<<"Banh cuon dac biet\t"<<this->d.getTrongLuongBanh()<<"\t"<<this->d.getTrongLuongNhan()<<"\t"<<this->d.getThanhTien()<<endl;
			cout<<"Tong tien: "<<a.getThanhTien()+b.getThanhTien()+c.getThanhTien()+d.getThanhTien()<<"d"<<endl;
		}
		
		int TienLai(){
    		return (a.getThanhTien() + b.getThanhTien() + c.getThanhTien() + d.getThanhTien()) * 0.1;
		}
};

class CuaHang
{
protected:
    string Ten;
    DonHang hoadon;

public:
    CuaHang(){
	}
    ~CuaHang(){
    	//cout<<"Huy tu"<<endl;	
	}
    string getTen() const;
    CuaHang(string Ten, DonHang hoadon)
{
    this->Ten = Ten;
    this->hoadon = hoadon;
}
int CuaHang::TienLai()
{
    return this->hoadon.TienLai();
}

string CuaHang::getTen() const
{
    return this->Ten;
}
    int TienLai();
};

int main()
{
	Chay hoa;
	hoa.print();
	
	Mong ti;
	ti.print();
	
    ThitLon trang;
    trang.print();
    
    DacBiet teo;
	teo.print();
	
	
	
}
