#include <iostream>
#include <vector>
using namespace std;

class banhcuon
{
protected:
    float gam_vo;
    float gia_vo;

public:
    banhcuon() {}
    ~banhcuon() {}
    float getgam_vo() const;
    float getgia_vo() const;
    virtual float tong_gia() = 0;
};
class banhcuon_chay : public banhcuon
{
protected:
    float gam_nhan_chay;
    float gia_nhan_chay;

public:
    banhcuon_chay() {}
    ~banhcuon_chay() {}
    float getgam_nhan_chay() const;
    float getgia_nhan_chay() const;
    banhcuon_chay(float gam_vo, float gam_nhan_chay, float gia_vo, float gia_nhan_chay);
    float tong_gia();
};
class banhcuon_mong : public banhcuon
{
protected:
    float gam_nhan_mong;
    float gia_nhan_mong;

public:
    banhcuon_mong() {}
    ~banhcuon_mong() {}
    float getgam_nhan_mong() const;
    float getgia_nhan_mong() const;
    banhcuon_mong(float gam_vo, float gam_nhan_mong, float gia_vo, float gia_nhan_mong);
    float tong_gia();
};
class banhcuon_thit : public banhcuon
{
protected:
    float gam_nhan_thit;
    float gia_nhan_thit;

public:
    banhcuon_thit() {}
    ~banhcuon_thit() {}
    float getgam_nhan_thit() const;
    float getgia_nhan_thit() const;
    banhcuon_thit(float gam_vo, float gam_nhan_thit, float gia_vo, float gia_nhan_thit);
    float tong_gia();
};
class banhcuon_dacbiet : public banhcuon_thit
{	
protected:
    float gam_nhan_cacuong;
    float gia_nhan_cacuong;

public:
    banhcuon_dacbiet() {}
    ~banhcuon_dacbiet() {}
    float getgam_nhan_thit() const;
    float getgia_nhan_thit() const;
    float getgam_nhan_cacuong() const;
    float getgia_nhan_cacuong() const;
    banhcuon_dacbiet(float gam_vo, float gam_nhan_thit, float gam_nhan_cacuong, float gia_vo, float gia_nhan_thit, float gia_nhan_cacuong);
    float tong_gia();
};
float banhcuon::getgam_vo() const
{
    return this->gam_vo;
}
float banhcuon::getgia_vo() const
{
    return this->gia_vo;
}

float banhcuon_chay::getgam_nhan_chay() const
{
    return this->gam_nhan_chay;
}
float banhcuon_chay::getgia_nhan_chay() const
{
    return this->gia_nhan_chay;
}
banhcuon_chay::banhcuon_chay(float gam_vo, float gam_nhan_chay, float gia_vo, float gia_nhan_chay)
{
    this->gam_vo = gam_vo;
    this->gia_vo = gia_vo;
    this->gam_nhan_chay = gam_nhan_chay;
    this->gia_nhan_chay = gia_nhan_chay;
}
float banhcuon_chay::tong_gia()
{
    return this->gam_vo * this->gia_vo + this->gam_nhan_chay * this->gia_nhan_chay;
}

float banhcuon_mong::getgam_nhan_mong() const
{
    return this->gam_nhan_mong;
}
float banhcuon_mong::getgia_nhan_mong() const
{
    return this->gia_nhan_mong;
}
banhcuon_mong::banhcuon_mong(float gam_vo, float gam_nhan_mong, float gia_vo, float gia_nhan_mong)
{
    this->gam_vo = gam_vo;
    this->gia_vo = gia_vo;
    this->gam_nhan_mong = gam_nhan_mong;
    this->gia_nhan_mong = gia_nhan_mong;
}
float banhcuon_mong::tong_gia()
{
    return this->gam_vo * this->gia_vo + this->gam_nhan_mong * this->gia_nhan_mong;
}

float banhcuon_thit::getgam_nhan_thit() const
{
    return this->gam_nhan_thit;
}
float banhcuon_thit::getgia_nhan_thit() const
{
    return this->gia_nhan_thit;
}
banhcuon_thit::banhcuon_thit(float gam_vo, float gam_nhan_thit, float gia_vo, float gia_nhan_thit)
{
    this->gam_vo = gam_vo;
    this->gia_vo = gia_vo;
    this->gam_nhan_thit = gam_nhan_thit;
    this->gia_nhan_thit = gia_nhan_thit;
}
float banhcuon_thit::tong_gia()
{
    return this->gam_vo * this->gia_vo + this->gam_nhan_thit * this->gia_nhan_thit;
}

float banhcuon_dacbiet::getgam_nhan_cacuong() const
{
    return this->gam_nhan_cacuong;
}
float banhcuon_dacbiet::getgia_nhan_cacuong() const
{
    return this->gia_nhan_cacuong;
}
banhcuon_dacbiet::banhcuon_dacbiet(float gam_vo, float gam_nhan_thit, float gam_nhan_cacuong, float gia_vo, float gia_nhan_thit, float gia_nhan_cacuong)
{
    this->gam_vo = gam_vo;
    this->gia_vo = gia_vo;
    this->gam_nhan_thit = gam_nhan_thit;
    this->gia_nhan_thit = gia_nhan_thit;
    this->gam_nhan_cacuong = gam_nhan_cacuong;
    this->gia_nhan_cacuong = gia_nhan_cacuong;
}
float banhcuon_dacbiet::tong_gia()
{
    return this->gam_vo * this->gia_vo + this->gam_nhan_thit * this->gia_nhan_thit + this->gam_nhan_cacuong * this->gia_nhan_cacuong;
}

class dongia :public banhcuon_chay, public banhcuon_mong, public banhcuon_thit, public banhcuon_dacbiet
{
protected:
    vector<banhcuon *> k;

public:
    dongia() {}
    ~dongia() {}
    dongia(banhcuon_chay, banhcuon_mong, banhcuon_thit, banhcuon_dacbiet);
    void in_ra_don_gia();
    int tien_lai();
};
dongia::dongia(banhcuon_chay , banhcuon_mong , banhcuon_thit , banhcuon_dacbiet )
{
	banhcuon_chay a;
   	banhcuon_mong b;
   	banhcuon_thit c;
   	banhcuon_dacbiet d;
}
void dongia::in_ra_don_gia()
{
    cout << "ID\t"
         << "Ten loai banh\t\t"
         << "Khoi Luong Vo\t"
         << "Khoi Luong Nhan\t\t"
         << "Gia" << endl;
    cout << "1\t"
         << "Banh Cuon Chay\t\t" << a.getgam_vo() << "\t\t" << a.getgam_nhan_chay() << "\t\t\t" << a.tong_gia() << endl;
    cout << "2\t"
         << "Banh Cuon Mong\t\t" << this->b.getgam_vo() << "\t\t" << this->b.getgam_nhan_mong() << "\t\t\t" << this->b.tong_gia() << endl;
    cout << "3\t"
         << "Banh CuongThit\t\t" << this->c.getgam_vo() << "\t\t" << this->c.getgam_nhan_thit() << "\t\t\t" << this->c.tong_gia() << endl;
    cout << "4\t"
         << "Banh Cuon Dac Biet\t" << this->d.getgam_vo() << "\t\t" << this->d.getgam_nhan_cacuong() << "\t\t\t" << this->d.tong_gia() << endl;
    cout << "\n\t\t\t\t\t\t\tTong so tien:\t" << a.tong_gia() + b.tong_gia() + c.tong_gia() + d.tong_gia() << endl;
}
int dongia::tien_lai()
{
    return (a.tong_gia() + b.tong_gia() + c.tong_gia() + d.tong_gia()) * 0.1;
}

class CuaHang
{
protected:
    string Ten;
    dongia hoadon;

public:
    CuaHang();
    ~CuaHang();
    string getTen() const;
    CuaHang(string, dongia);
    int sotienlai();
};
CuaHang::CuaHang() {}
CuaHang::~CuaHang() {}
CuaHang::CuaHang(string Ten, dongia hoadon)
{
    this->Ten = Ten;
    this->hoadon = hoadon;
}
int CuaHang::sotienlai()
{
    return this->hoadon.tien_lai();
}
string CuaHang::getTen() const
{
    return this->Ten;
}


class GiangCuon
{
    static int soluongcuahang;

private:
    CuaHang so_luong[1000];

public:
    GiangCuon() {}
    ~GiangCuon() {}
    GiangCuon(CuaHang);
    void themcuahang(CuaHang);
    void inratatcacuonghang();
};
int GiangCuon::soluongcuahang = 0;
GiangCuon::GiangCuon(CuaHang x)
{
    this->so_luong[soluongcuahang] = x;
    soluongcuahang++;
}
void GiangCuon::inratatcacuonghang()
{
    int add = 0;
    for (int i = 0; i < soluongcuahang; i++)
    {
        add = add + this->so_luong[i].sotienlai();
        cout << this->so_luong[i].getTen() << "\t\t" << this->so_luong[i].sotienlai() << endl;
    }
    cout << "Tong So Tien Lai La:  " << add << endl;
}
void GiangCuon::themcuahang(CuaHang a)
{
    this->so_luong[soluongcuahang] = a;
    soluongcuahang++;
}









int main()
{
	return 0;
}
