#include<iostream>
#include "btvn44.h"
#include <stdlib.h>
using namespace std;
long long int Sum(long long int a,long long int b, long long int c, long long int d)
{
    long long int T;
    T=a*b+c*d;
    return T;
}    
class BanhCuon
{
	protected:
		long long int giavo;
		long long int soluongvo;
		long long int soluongnhan;
	public:
		BanhCuon(long long int gv,long long int slv,long long int sln){
		    setGiaVo(gv);
		    setSoLuongVo(slv);
			setSoLuongNhan(sln);
		}
		void setGiaVo(long long int gv)
			{
			giavo=gv;
			}
		long long int getGiaVo()
			{
			return giavo;
			}
		void setSoLuongVo(long long int slv)
			{
			soluongvo=slv;
			}
		long long int getSoLuongVo()
		    {
		    return soluongvo;
		    }
		void setSoLuongNhan(long long int sln)
			{
			soluongnhan=sln;
			}
		long long int getSoLuongNhan()
			{
			return soluongnhan;
			}
	    virtual void print()
	    {
	        cout<<"Giá Vỏ: "<<giavo<<"/100g"<<endl;
	        cout<<"Số Lượng Vỏ: "<<soluongvo<<"g"<<endl;
	        cout<<"Số Lượng Nhân: "<<soluongnhan<<"g"<<endl;
	    }
		~BanhCuon(){};
		

};
class BanhCuonChay : public BanhCuon
{
    private:
        long long int gianhanchay;
	public:
		BanhCuonChay(long long int gv,long long int slv,long long int sln,long long int gnc) : BanhCuon(gv,slv,sln)
            {
                setGiaNhanChay(gnc);
                }
		    void setGiaNhanChay(long long int gnc)
		        {
		            gianhanchay=gnc;
		        }
		    long long int getGiaNhanChay()
		        {
		            return gianhanchay;
		        }
        ~BanhCuonChay(){};
		virtual void print()
		{
		    BanhCuon::print();
		    cout<<"Giá Nhân Chay: "<<gianhanchay<<"/100g"<<endl;
		    cout<<"Tổng Số Tiền: "<<(giavo/100 * soluongvo) + (gianhanchay/100 * soluongnhan)<<"VND"<<endl;
		}
				 
};
class BanhCuonMong : public BanhCuon
{
    private:
        long long int gianhanmong;
	public:
		BanhCuonMong(long long int gv,long long int slv,long long int sln,long long int gnm) : BanhCuon(gv,slv,sln)
            {
                setGiaNhanMong(gnm);
                }
		    void setGiaNhanMong(long long int gnm)
		        {
		            gianhanmong=gnm;
		        }
		    long long int getGiaNhanMong()
		        {
		            return gianhanmong;
		        }
        ~BanhCuonMong(){};
		virtual void print()
		{
		    BanhCuon::print();
		    cout<<"Giá Nhân Mỏng: "<<gianhanmong<<"/100g"<<endl;
		    cout<<"Tổng Số Tiền: "<<(giavo/100 * soluongvo) + (gianhanmong/100 * soluongnhan)<<"VND"<<endl;
		}
				 
};
class BanhCuonThit : public BanhCuon
{
    protected:
        long long int gianhanthit;
	public:
		BanhCuonThit(long long int gv,long long int slv,long long int sln,long long int gnt) : BanhCuon(gv,slv,sln)
            {
                setGiaNhanThit(gnt);
                }
		    void setGiaNhanThit(long long int gnt)
		        {
		            gianhanthit=gnt;
		        }
		    long long int getGiaNhanThit()
		        {
		            return gianhanthit;
		        }
        ~BanhCuonThit(){};
		virtual void print()
		{
		    BanhCuon::print();
		    cout<<"Giá Nhân Thịt: "<<gianhanthit<<"/100g"<<endl;
		    cout<<"Tổng Số Tiền: "<< giavo/100 * soluongvo + gianhanthit/100 * soluongnhan<<"VND"<<endl;
		}
				 
};
class BanhCuonDacBiet : public BanhCuon
{
    private:
        long long int gianhandacbiet;
	public:
		BanhCuonDacBiet(long long int gv,long long int slv,long long int sln,long long int gndb) : BanhCuon(gv,slv,sln)
            {
                setGiaNhanDacBiet(gndb);
                }
		    void setGiaNhanDacBiet(long long int gndb)
		        {
		            gianhandacbiet=gndb;
		        }
		    long long int getGiaNhanDacBiet()
		        {
		            return gianhandacbiet;
		        }
        ~BanhCuonDacBiet(){};
		virtual void print()
		{
		    BanhCuon::print();
		    cout<<"Giá Nhân Đặc Biệt: "<<gianhandacbiet<<"/100g"<<endl;
		    cout<<"Tổng Số Tiền: "<<giavo/100 * soluongvo + gianhandacbiet/100 * soluongnhan<<"VND"<<endl;
		}
				 
};

void cuahang()
{
        int chon;
        int d;
        cout<<"nh?n s? 1 ?? b?t ??u  "<<endl;
        cin>>d;
        system("clear");
        chon=Menu();
        int m=0;
        while(d!=0 or chon!=0)
        {
            if (chon==0)
                {
                    cout<<"Chúc Quý Khách Một Ngày Tốt Lành\n";
                }
            else if (chon==1)
                {
                    int a,b;
                    cout<<"Mời Bạn Nhập số Lượng vỏ(g): "<<endl;             
                    cin>>a;
                    cout<<"Mời Bạn Nhập số Lượng Nhân(g): "<<endl;
                    cin>>b;
                    BanhCuonChay Banhchay(10000,a,b,15000);
                    Banhchay.print();
                    cout<<"Chúc Quý Khách Một Ngày Tốt Lành\n";
            
                }
            else if (chon==3)
                {
                    int a,b;
                    cout<<"Mời Bạn Nhập số Lượng vỏ(g): "<<endl;             
                    cin>>a;
                    cout<<"Mời Bạn Nhập số Lượng Nhân(g): "<<endl;
                    cin>>b;
                    BanhCuonMong Banhmong(10000,a,b,10000);
                    Banhmong.print();
                    cout<<"Chúc Quý Khách Một Ngày Tốt Lành\n";
               
                }
            else if (chon==3)
                {
                    int a,b;
                    cout<<"Mời Bạn Nhập số Lượng vỏ(g): "<<endl;             
                    cin>>a;
                    cout<<"Mời Bạn Nhập số Lượng Nhân(g): "<<endl;
                    cin>>b;
                    BanhCuonThit Banhthit(10000,a,b,20000);
                    Banhthit.print();
                    cout<<"Chúc Quý Khách Một Ngày Tốt Lành\n";
                
                }
            else if (chon==4)
                {
                    int a,b;
                    cout<<"Mời Bạn Nhập số Lượng vỏ(g): "<<endl;             
                    cin>>a;
                    cout<<"Mời Bạn Nhập số Lượng Nhân(g): "<<endl;
                    cin>>b;
                    BanhCuonDacBiet Banhdacbiet(10000,a,b,30000);
                    Banhdacbiet.print();
                
                }
            int m=m+m;
            if (m==3)
            {
            	break;
			}
             }
}
int main()
{
    cuahang();
    return 0;
}
