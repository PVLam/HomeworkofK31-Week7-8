#include <string.h>
#include <fstream>
using namespace std;
int Menu()
{
    cout<<"Chào Mừng Bạn Đến Với Cửa Hàng:\n";
    cout<<"1. Bánh Cuốn Chay: Bánh có nhân làm từ các loại nấm, mộc nhĩ, rau củ, ...\n";
    cout<<"2. Bánh Cuốn Mỏng: Bánh chỉ có vỏ và hành phi mỡ \n";
    cout<<"3. Bánh Cuốn Thịt: Bánh có nhân làm từ thịt lợn, mộc nhĩ, nấm hương, rau củ, ...\n";
    cout<<"4. Bánh Cuốn Đặc Biệt: Giống bánh cuốn nhân thịt lợn nhưng bổ sung thêm thịt cà cuống vào nước chấm \n";
    cout<<"0. Exit\n";
    cout<<"M?i b?n nh?n 1, 2, 3, 4 ?? Order b�nh:  ";
    int chon;
    cin>>chon;
    return chon;
}

