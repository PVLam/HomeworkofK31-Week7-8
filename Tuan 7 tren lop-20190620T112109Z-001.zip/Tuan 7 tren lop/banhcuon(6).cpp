#include<iostream>
using namespace std;
class banhcuon{
    private:
        int giavo;  
    public:
        Banhcuon(int vo=10000)
        {
            setgiavo(vo);
        } 
        void setgiavo(int x)
        {
            giavo=x;
        }
        int getgiavo()
        {
            return giavo;
        }
        ~Banhcuon{
        }
              
        
};
class Banhcuonchay : public Banhcuon
{
    private:
        int gianhanraucu;
    public:
        Banhcuon(vo)
        {
            setgianhanraucu(gianhanraucu);
        }
        void setgianhanraucu(int x)
        {
            gianhanraucu=x;
        }
        int getgianhanraucu()
        {
            return gianhanraucu;
        }
}; 
class Banhcuonmong : public Banhcuon
{
    private:
        int gianhanhanh;
    public:
        Banhcuonchay(int vo=10000,int giahanh=10000)
        :Banhcuon(vo)
        {
            setgianhanhanh(gianhanhanh);
        }
        void setgianhanhanh(int x)
        {
            gianhanhanh=x;
        }
        }
        int getgianhanhanh()
        {
            return gianhanhanh;
        }
           
};       
