#include <iostream>
using namespace std;
class BanhCuon
{
	private :
		int vo;
	public:
		BanhCuon(int v=10000)
		{
			setVo(v);
		}
		void setVo(int vo)
		{
			vo=v;
		}
		int getVo()
		{
			return vo;
		}
		~BanhCuon()
		{
		}
};

class BanhCuonChay : public BanhCuon 
{
	private:
		int nhanrau;
	public:
		BanhCuonChay(int v=10000, int nrau=15000)
		:BanhCuon(v)
		{
			setNhanRau(nrau);
		}
		void setNhanRau(int nrau)
		{
			nhanrau=nrau;
		}
		int getNhanRau()
		{
			return nhanrau;
		}
		~BanhCuonChay()
		{
		}
};

class BanhCuonMong : public BanhCuon 
{
	private:
		int nhanmo;
	public:
		BanhCuonMong(int v=10000, int nmo=10000)
		:BanhCuon(v)
		{
			setNhanMo(nmo);
		}
		void setNhanMo(int nmo)
		{
			nhanmo=nmo;
		}
		int getNhanMo()
		{
			return nhanmo;
		}
		~BanhMong()
		{
		}
};

class BanhCuonThitLon : public BanhCuon 
{
	private:
		int nhanthit;
	public:
		BanhCuonChay(int v=10000, int nthit=20000)
		:BanhCuon(v)
		{
			setNhanThit(nthit);
		}
		void setNhanThit(int nthit)
		{
			nhanrau=nrau;
		}
		int getNhanThit()
		{
			return nhanthit;
		}
		~BanhCuonThit()
		{
		}
};

class BanhCuonDacBiet : public BanhCuonThit 
{
	private:
		int cacuong;
	public:
		BanhCuonDacBiet(int v=10000, int nthit=20000, int cacu=30000)
		:BanhCuonThit(v,nthit)
		{
			setCaCuong(cacu);
		}
		void setCaCuong(int cacu)
		{
			cacuong=cacu;
		}
		int getCaCuong()
		{
			return cacuong;
		}
		~BanhCuonDacBiet()
		{
		}
};






