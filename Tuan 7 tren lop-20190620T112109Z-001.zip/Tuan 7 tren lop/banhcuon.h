#ifndef BANHCUON_H
#define BANHCUON_H
class BanhCuon
{
	private:
		double giavo;
	public:	
		BanhCuon(double a=10000){
			setGiavo(a);
		}	
		void setGiavo(double a){
			giavo=a;
		}	
		double getGiavo(){
			return giavo;
		}	
		void TinhTien(double c)
		{
			cout<<"So tien vo la: "<<100000*c<<" (theo kilogam)"<<endl;
		}		
		~BanhCuon(){
		}
};
class BanhCuonChay: public BanhCuon
{
	private:
		double gianhanchay;
	public:
		BanhCuonChay(double a=15000){
			setGianhanchay(a);
		}
		void setGianhanchay(double a)
			gianhanchay=a;
		double getGianhanchay()
			return gianhanchay;
		void TinhTien(double c)
		{
			BanhCuon:: TinhTien();
			cout<<"So tien nhan la: "<<150000*c<<" (theo kilogam)"<<endl; 
		}		
		~BanhCuonChay()



};

#endif
