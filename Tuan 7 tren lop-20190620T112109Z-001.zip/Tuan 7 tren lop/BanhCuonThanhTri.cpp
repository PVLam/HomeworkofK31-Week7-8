#include<iostream>
using namespace std;

class giaBanhCuon
{
	private:
		int giaVo;
		int giaNhan;
		int weightVo;
		int weightNhan;
	public:
		BanhCuon(int priceVo = 0, int priceNhan = 0, int klVo = 0, int klNhan = 0)
		{
			int giaVo = priceVo;
			int giaNhan = priceNhan;
			int weightVo = klVo;
			int weightNhan = klNhan;
			
		}
		
		int giaDonHang()
		{
			int x ;
			x = giaVo*weightVo + giaNhan*weightNhan
		}
		
		
		
};

int main()
{
	
}
