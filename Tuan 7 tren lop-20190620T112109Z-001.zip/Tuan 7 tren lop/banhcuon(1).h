using namespace std;



class banhCuon
{
	private:
		string loaiBanh;
		int giaVo;
		int giaNhan;
		int weighVo;
		int weighNhan;
		
	public:
		banhCuon(string lb="Banh cuon", int gv=10000, int wv=0, int gn=0, int wn=0)
		:loaiBanh(lb), giaVo(gv), giaNhan(gn), weighVo(wv), weighNhan(wn){}
		
		void setLoaiBanh(string lb)
		{
			loaiBanh=lb;
		}
		void setGiaVo(int gv)
		{
			giaVo=gv;
		}
		void setGiaNhan(int gn)
		{
			giaNhan=gn;
		}
		void setWeighVo(int wv)
		{
			weighVo=wv;
		}
		void setWeighNhan(int wn)
		{
			weighNhan=wn;
		}
		void getLoaiBanh(string lb)
		{
			cout<<lb<<endl;
		}
		void getGiaVo(int gv)
		{
			return gv;
		}
		
		
		
			
		~banhCuon(){};
};
