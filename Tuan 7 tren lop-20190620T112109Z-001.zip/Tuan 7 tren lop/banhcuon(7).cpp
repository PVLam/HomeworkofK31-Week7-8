#include <bits/stdc++.h>
using namespace std;
class BanhCuon{
	protected:
		int giavo;
		int soluong;
	public:
		BanhCuon(int giavo=10000,int soluongg=0){
		
		}
		~BanhCuon(){}
};
class BanhCuonChay{
	private:
		int gianhan;
		int soluong;
	public:
		BanhCuonChay(int gianhann=15000,int soluongg=0){
			SetGiaNhan(gianhann);
			SetSoLuong(soluongg);
		}
		void SetGiaNhan(int gianhann){
			gianhan=gianhann;
		}
		int GetGiaNhan(){
			return gianhan;
		}
		void SetSoLuong(int soluongg){
			soluong=soluongg;
		}
		int GetSoLuong(){
			return soluong;
		}
		void TinhTien(){
			int sum=gianhan*soluong+10000;
			cout<<sum<<endl;
		}
		~BanhCuonChay(){}
};
class BanhCuonMong:public BanhCuonChay{
	private:

};

int main(){
	BanhCuonChay chay(15000,3);
	chay.TinhTien();
	return 0;
}