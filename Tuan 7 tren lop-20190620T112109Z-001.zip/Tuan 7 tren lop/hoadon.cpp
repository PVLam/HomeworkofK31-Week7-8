 #include <iostream>
 using namespace std;
 class hoadon
{
    private:
     float tongtiendonhang;
     int chietkhau;
     int donhang ;
    public:
     hoso(void);
     ~hoso(void);
     void nhapdon();
     void xuatdon();
     float sotienthanhtoan();
     
    void xuatdon()
    {
   	cout<<"tong don hang cua ban la: "<<endl;

     
    }
    void menu()
    {
        cout<<"Moi ban chon do: "<<endl;
        cout<<"1. Banh cuon chay 25K"<<endl<<"2. Banh cuon mong"<<endl;
        cout<<"3. banh cuon dac biet 30K"<<endl;
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
};


