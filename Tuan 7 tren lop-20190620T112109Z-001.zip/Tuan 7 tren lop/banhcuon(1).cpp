#include<iostream>
using namespace std;
class BanhCuon
{
	protected:
		double giavo;
	public:
		BanhCuon(double gv=10000){}
		~BanhCuon(){};

};
class BanhCuonChay:public BanhCuon
{
	private:
		double gianhanchay;
		double soluong;
	public:
		BanhCuonChay(double gv=10000,double gnc=0,double sl=0) : BanhCuon(gv)
		{
			setGiaNhanChay(gnc);
			setSoLuong(sl);
		}
		void setGiaNhanChay(double gnc)
			{gianhanchay=gnc;}
		double getGiaNhanChay()
			{return gianhanchay;}
		void setSoLuong(double sl)
			{soluong=sl;}
		double getSoLuong()
			{return soluong;}
		void TongSoTien()
			{
				int T;
				T=gianhanchay*soluong+giavo;
				cout<<T<<endl;
			}
		 
};
int main()
{

}
