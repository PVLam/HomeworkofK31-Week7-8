class BanhCuon
{
	private:
		string tenbanh;
		float giaban;
		float khoiluong;
	public:
		BanhCuon(string ten="",float gia=0, float m=0)
		~BanhCuon()
		
		void setTen(string ten) 
		{
			tenbanh = ten;
		}
		string getTen()
		{
			return tenbanh;
		}
		
		void setGia(float gia)
		{
			giaban = gia;
		}
		float getGia()
		{
			return giaban;
		}
		
		void setKL(float m)
		{
			khoiluong = m;
		}
		float getKL()
		{
			return khoiluong;
		}
};

class HoaDon()
class DoanhThu()
{
	private:
		float tong;
	public:
};
		
