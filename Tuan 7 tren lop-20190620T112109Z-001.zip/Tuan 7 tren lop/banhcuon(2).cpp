#include <iostream>
using namespace std;

class BanhCuon
{
	private:
		int vo;
	public:
		BanhCuon(int vo=10000)
		{
			setVo(vo);
		}
		void setVo(int vo)
		{
			this->vo=vo;
		}
		int getVo()
		{
			return vo;
		}
		~BanhCuon()
		{}
};

class BanhCuonChay : public BanhCuon
{
	private:
		int nhancuqua;
	public:
		BanhCuonChay(int vo=10000, int nhancuqua=15000)
		:BanhCuon(vo)
		{
			setNhanCuQua(nhancuqua);
		}
		void setNhanCuQua(int nhancuqua)
		{
			this->nhancuqua=nhancuqua;
		}
		int getNhanCuQua()
		{
			return nhancuqua;
		}
		
		~BanhCuonChay()
		{}
};

class BanhCuonMong : public BanhCuon
{
	private:
		int nhanhanh;
	public:
		BanhCuonMong(int vo=10000, int nhanhanh=20000)
		:BanhCuon(vo)
		{
			setNhanHanh(nhanhanh);
		}
		void setNhanHanh(int nhanhanh)
		{
			this->nhanhanh=nhanh;
		}
		int getNhanHanh()
		{
			return nhanhanh;
		}
		~BanhCuonMong()
		{}
		
};



class BanhCuonThit : public BanhCuon
{
	private:
		int nhanthit;
	public:
		BanhCuonThit(int vo=10000, int nhanthit=10000)
		:BanhCuon(vo)
		{
			setNhanThit(nhanthit);
		}
		void setNhanThit(int nhanthit)
		{
			this->nhanthit=nhanthit;
		}
		int getNhanThit()
		{
			return nhanthit;
		}
		~BanhCuonThit()
		{}
		
};


class BanhCuonDacBiet : public BanhCuonThit
{
	private:
		int nhannuoc;
	public:
		BanhCuonDacBiet(int vo=10000, int nhanthit=10000, int nhannuoc=30000)
		:BanhCuon(vo,nhanthit)
		{
			setNhanNuoc(nhannuoc);
		}
		void setNhanNuoc(int nhannuoc)
		{
			this->nhannuoc=nhannuoc;
		}
		int getNhanNuoc()
		{
			return nhannuoc;
		}
		~BanhCuonDacBiet()
		{}
		
};










