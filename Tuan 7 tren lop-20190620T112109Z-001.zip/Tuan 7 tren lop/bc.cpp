#include<iostream>
using namespace std ;
class banhcuon{
private:
    double giavo;
    double gianhan;
    
public :
    banhcuon(double vo=0 , double nhan=0){
        setgiavo(vo);
        setgianhan(nhan);
        }
    void setgiavo(double vo){
        giavo = vo ; 
        }
    void setgianhan(double nhan){
        gianhan = nhan ; 
        }
     void print(){
        cout<<giavo<<" "<<gianhan<<" "<<endl;
        } 
    ~banhcuon(){
    //    cout<<huytu<<endl;
     }
};
class chay :public banhcuon
{
    public:
         chay(double vo=10000 , double nhan=15000):
         banhcuon(vo,nhan){
         }  
    void print(){
        banhcuon::print();
        }
    };



int main(){
    chay a;
    a.print();
}

