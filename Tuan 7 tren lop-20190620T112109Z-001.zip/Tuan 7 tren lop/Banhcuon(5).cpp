#include<iostream>
#include "banhcuon.h"
using namespace std;
int main()
{
	banhCuon("dsfas",21,32,54,76);
	return 0;	
}
