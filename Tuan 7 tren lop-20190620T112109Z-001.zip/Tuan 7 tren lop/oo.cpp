#include <iostream>
using namespace std;


class BanhCuon
	{
		protected:
			string name;
			double giavo;
		public:
			BanhCuon()
			{
			}
			void setGiaVo(double vo)
			{
				giavo = vo;
			}
			
			double getGiaVo()
			{
				return giavo;
			}
			~BanhCuon()
			{
			}

};

class BanhCuonChay : public BanhCuon
{
	private:
		double nhanchay;
	public:
		
		BanhCuonChay(string Name = "Banh Cuon Chay", double NhanChay = 15000)
		{
			nhanchay = NhanChay;
		}
		void setNhanChay(double chay)
		{
			nhanchay = chay;
		}
		
		double getNhanChay()
		{
			return nhanchay;
		}
};

class BanhCuonMong : public BanhCuon
{
	private:
		double nhanmong;
	public:
		BanhCuonMong(string Name = "Banh Cuon Mong", double NhanMong = 10000)
		{
			NhanMong = nhanmong;
		}
		void setNhanMong(double mong)
		{
			nhanmong = mong;
		}
		
		double getNhanMong()
		{
			return nhanmong;
		}
};




























int main()
{
	return 0;
}
