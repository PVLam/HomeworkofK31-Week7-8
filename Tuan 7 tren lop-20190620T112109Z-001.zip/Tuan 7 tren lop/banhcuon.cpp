#include <iostream>
using namespace std;

class BanhCuon
{
	private:
		double giavo;
	public: 
		BanhCuon(double GIAVO = 10000)
		{
			giavo = GIAVO;	 
		}
		void setGiaVo(double v);
		double getGiaVo();
		~BanhCuon()
		{
		
		}
		
};
void BanhCuon::setGiaVo(double v)
{
	giavo = v;
}
double BanhCuon::getGiaVo()
{
	return giavo;
}

class BanhCuonChay : public BanhCuon
{
	private:
		double gianhan;
	public:
		BanhCuonChay(double GIANHAN = 15000,double 	GIAVO = 10000)
		{
			giavo = GIAVO;
			gianhan = GIANHAN;
		}
		void setGiaNhan(double n);
		double getGiaNhan();
		~BanhCuonChay()
		{
		
		}
};

void BanhCuonChay::setGiaNhan(double n)
{
	gianhan = n;
}
double BanhCuonChay::getGiaNhan()
{
	return gianhan;
}





















int main()
{

	return 0;
}
