#include <iostream>
using namespace std;
class banhcuon
{
    private:
        int vo;
    public:
        banhcuon(int vo=10000)
        {
            setvo(v);
        }
        void setvo(int v)
        {
            vo=v;
        }
        int getvo()
        {
            return v;
        }
        ~banhcuon();
};
class banhcuonchay :: public banhcuon
{
    private:
        int nhan1;
    public:
        banhcuonchay(int vo=10000; int nhan1=15000)
        {
            setnhan1(n1);
        }
        void setnhan1(int n1)
        {
            nhan1=n1;
        }
        int getnhan()
        {
            return n1;
        }
        ~banhcuonchay()
};
class banhcuonmong :: public banhcuon
{
    private:
        int nhan2;
    public:
        banhcuonmong(int vo=10000;int nhan2=10000)
        {
            setnhan2(n2);
        }
        void setnhan2(int n2)
        {
            setnhan2=n2;
        }
        int getnhan2(n2);
        {
            return n2;
        }
        ~banhcuonmong();
};
class banhcuonthitlon :: public banhcuon
{
    private:
        int nhan3;
    public:
        banhcuonthitlon(int vo=10000;int nhan3=2000)
        {
            setnhan3(n3);
        }
        void setnhan3(int n3)
        {
            nhan3=n3;         
        }
        int getnhan3()
        {
            return n3;
        }
};
class banhcuondacbiet :: public banhcuonthitlon
{
    private:
        int thit;
    public:
        banhcuondacbiet(int vo=10000; int thit=30000)
        {
            setthit(t);
        } 
        void setthit(int t)
        {
            thit=t;
        }
        int getthit()
        {
            return t;
        }
};
class hoadon
{
    private:
    char banhcuonchay;
    char banhcuonmong;
    char banhcuonthitlon;
    char banhcuondacbiet;
        
