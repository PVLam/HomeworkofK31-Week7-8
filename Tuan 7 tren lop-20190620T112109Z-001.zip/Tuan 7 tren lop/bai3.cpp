#include<iostream>
using namespace std;
class BanhCuon{
    private:
        double gia_nhan;
        double gia_vo;
        
    public:
        BanhCuon(double gv,double gn){
            setGiaNhan(gn);
            setGiaVo(gv);
        }
        void setGiaNhan(double gn){
            gia_nhan=gn;
        }
        double getGiaNhan(){
            return gia_nhan;
        }
        void setGiaVo(double gv){
            gia_vo=gv;
        }
        double getGiaVo(){
            return gia_vo;
        }
        void print(){
            cout<<"Gia vo:"<<gia_vo<<endl;
            cout<<"Gia nhan:"<<gia_nhan<<endl;
        }
        ~BanhCuon(){
            //cout<<"Huy tu"<<endl;
        }
};

class Chay:public BanhCuon{
    public:
        Chay(double gv=10000,double gn=15000):BanhCuon(gv,gn){
            setGiaNhan(gn);
        }
        void print(){
            BanhCuon::print();
        }
        ~Chay(){
            //cout<<"Huy tu"<<endl;
        }
};

class Mong:public BanhCuon{
    public:
        Mong(double gv=10000,double gn=10000):BanhCuon(gv,gn){
        }
        void print(){
            BanhCuon::print();
        }
        ~Mong(){
            //cout<<"Huy tu"<<endl;
        }
};

class ThitLon:public BanhCuon{
    public:
        ThitLon(double gv=10000,double gn=20000):BanhCuon(gv,gn){
        }
        void print(){
            BanhCuon::print();
        }
        ~ThitLon(){
            //cout<<"Huy tu"<<endl;
        }
};

class DacBiet:public BanhCuon{
    public:
        DacBiet(double gv=10000,double gn=30000):BanhCuon(gv,gn){
        }
        void print(){
            BanhCuon::print();
        }
        ~DacBiet(){
            //cout<<"Huy tu"<<endl;
        }
};
int main()
{
    ThitLon trang;
    trang.print();
    return 0;
}
