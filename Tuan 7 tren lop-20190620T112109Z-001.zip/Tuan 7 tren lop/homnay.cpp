#include <iostream>
using namespace std;
class Banh
{
    private:
        double Vo;
        double Kg;
        
    public:
        Banh(double Vo,double Kg){
            
        
        }
        void setVo(double a){this->Vo=Vo;}
        double getVo(){return Vo;}
        void setKg(double x){this->Kg=Kg;}
        double getKg(){return Kg;}
        void print(){
            cout<<"So tien la: "<<Vo<<"/"<<Kg<<"g"<<endl;
        }
        Banh operator+(int i){
			this->Vo=Vo+i;
			this->Kg=Kg+i;
			return *this;
		}
};

int main()
{
    
    return 0;
}
